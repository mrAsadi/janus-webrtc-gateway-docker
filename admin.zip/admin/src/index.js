const express = require('express')
const morgan = require('morgan')
const helmet = require('helmet')
const bodyparser = require('body-parser')
const cors = require('cors')
const superagent = require('superagent')
const fetch = require('node-fetch');
const Bluebird = require('bluebird');
const crypto = require('crypto');
fetch.Promise = Bluebird;

const JanusAdmin = require('janus-admin').JanusAdmin;

function getJanusToken(realm, data = [],secret,timeout = 1 * 60 * 60) {
  const expiry = Math.floor(Date.now() / 1000) + timeout;

  const strdata = [expiry.toString(), realm, ...data].join(',');
  const hmac = crypto.createHmac('sha1','moshjserver');
  hmac.setEncoding('base64');
  hmac.write(strdata);
  hmac.end();

  return [strdata, hmac.read()].join(':');
};

var admin = new JanusAdmin({
    url: 'http://localhost:7088',
    secret: 'moshjserver'
});

const app = express()
app.use(morgan('dev'))
app.use(bodyparser.json())
app.use(helmet())
var whitelist = ['http://localhost:8080', 'https://dev.moshaverline.com']
var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  },
 methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
 credentials:true
}
app.use(cors(corsOptions))
/*app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin","https://dev.moshaverline.com");
  res.header("Access-Control-Allow-Credentials", true);
  res.header("Access-Control-Allow-Methods", "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers"," Access-Control-Allow-Origin, Access-Control-Allow-Headers, Origin, X-Requested-With, Content-Type, Accept_Language, Set-Cookie, Cookie, Authorization,X-XSRF-TOKEN");
  res.header("Access-Control-Max-Age", 86400); 
  next();
});
*/

const port = 3030

// Methods
// List sessions


app.get('/', (req, res) => {

    admin.listSessions().then((result)=>{
        res.send(result.sessions)
    }).catch(req.next)
  });

// List handles


app.post('/handles', (req, res) => {
    admin.listHandles(req.body.sessionId).then((result)=>{
        res.send(result.handles)
    }).catch(req.next)
  });

// Show single handle


app.post('/handles/single', (req, res) => {
    admin.handleInfo(req.body.sessionId,req.body.handleId).then((result)=>{
        res.send(result.info)
    }).catch(req.next)
  });

// Set the log level


app.post('/loglevel', (req, res) => {
    admin.setLogLevel(req.body.loglevel).then((result)=>{
        res.send(result.level)
    }).catch(req.next)
  });

// Set locking debug


app.post('/lockdebug', (req, res) => {
    admin.setLockingDebug(req.body.lockdebug).then((result)=>{
        res.send(result.debug)
    }).catch(req.next)
  });

// Methods (token based authentication)
// Add token

app.post('/token', (req, res) => {
    const token = getJanusToken('janus', ['janus.plugin.textroom'],req.body.token)
    admin.addToken(token).then((result)=>{
        res.send({'token':token,'plugins':result.plugins})
    }).catch(req.next)
  });

// Allow token

app.post('/token/allow', (req, res) => {
    admin.allowToken(req.body.token,req.body.plugins).then((result)=>{
        res.send(result.plugins)
    }).catch(req.next)
  });

// Disallow token

app.post('/token/disallow', (req, res) => {
    admin.disallowToken(req.body.token,req.body.plugins).then((result)=>{
        res.send(result.plugins)
    }).catch(req.next)
  });

// List all tokens

app.post('/token/list', (req, res) => {
    admin.listTokens().then((result)=>{
        res.send(result.tokens)
    }).catch(req.next)
  });

// Remove token

app.post('/token/remove', (req, res) => {
    admin.removeToken(req.body.token).then(()=>{
        res.send({"success":true})
    }).catch((err)=>{
        res.send({"success":false,"error":err})
    });
});

// Remove all tokens
app.post('/token/removeall', (req, res) => {
    admin.removeAllTokens().then(()=>{
        res.send({"success":true})
    }).catch((err)=>{
        res.send({"success":false,"error":err})
    });
});

app.listen(port, (err) => {
  if (err) {
    return console.log('something bad happened', err)
  }

  console.log(`server is listening on ${port}`)
})
